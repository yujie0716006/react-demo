/*
actions-types中的内容是 action对象的type 常量名称模块
* */
export const INCREASE = 'INCREASE'
export const DECREASE = 'DECREASE'